package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;

public class TelaTemasController {

    @FXML private CheckBox cbAnimais;
    @FXML private CheckBox cbAlimentos;
    @FXML private CheckBox cbDiversos;
  
    @FXML private CheckBox cbEsportes;
    @FXML private CheckBox cbNovelas;
    @FXML private CheckBox cbObjetos;
    @FXML private CheckBox cbPC;
    @FXML private CheckBox cbProfissoes;
    @FXML private Button btnIniciar;

    @FXML
    public void initialize() {
        btnIniciar.setOnAction(e -> {
            System.out.println("Temas selecionados:");
            if (cbAnimais.isSelected()) System.out.println("Tema 1 ");
            if (cbAlimentos.isSelected()) System.out.println("Tema 2");
            if (cbDiversos.isSelected()) System.out.println("Tema 3");
            if (cbEsportes.isSelected()) System.out.println("Tema 4");
            if (cbNovelas.isSelected()) System.out.println("Tema 5");
            if (cbObjetos.isSelected()) System.out.println("Tema 6");
            if (cbPC.isSelected()) System.out.println("Tema 7");
            if (cbProfissoes.isSelected()) System.out.println("Tema 8");
        });
    }
}
