pacote para guardar imagens usadas nas telas. 
