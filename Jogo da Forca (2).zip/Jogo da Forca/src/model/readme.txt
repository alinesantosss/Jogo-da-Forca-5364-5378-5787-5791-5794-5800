pacote para guardar gets,sets  e construtores necessários. 

